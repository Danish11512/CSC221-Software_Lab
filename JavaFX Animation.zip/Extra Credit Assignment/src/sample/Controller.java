// By Danish Faruqi - CSC 22100-R
// If it glitches just run it again
package sample;

import animatefx.animation.*;
import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.shape.Circle;
import javafx.util.Duration;

import java.net.URL;
import java.util.ResourceBundle;

public class Controller implements Initializable {

    @FXML
    private Circle circle2;

    public Circle getCircle2() {
        return circle2;
    }

    @FXML
    private Circle circle3;

    public Circle getCircle3() {
        return circle3;
    }

    @FXML
    private Circle circle1;

    public Circle getCircle1() {
        return circle1;
    }

    @FXML
    private Circle circle6;

    public Circle getCircle6() {
        return circle6;
    }

    @FXML
    private Circle circle7;

    public Circle getCircle7() {
        return circle7;
    }

    @FXML
    private Circle circle4;

    public Circle getCircle4() {
        return circle4;
    }

    @FXML
    private Circle circle5;

    public Circle getCircle5() {
        return circle5;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        // Appear

            FadeTransition fadeTransition3 = new FadeTransition(Duration.millis(3000), circle3);
            fadeTransition3.setFromValue(0);
            fadeTransition3.setToValue(1);
            fadeTransition3.setDuration(Duration.seconds(2));
            fadeTransition3.play();

            FadeTransition fadeTransition5 = new FadeTransition(Duration.millis(3000), circle5);
            fadeTransition5.setFromValue(0);
            fadeTransition5.setToValue(1);
            fadeTransition5.setDuration(Duration.seconds(2));
            fadeTransition5.play();

            FadeTransition fadeTransition6 = new FadeTransition(Duration.millis(3000), circle6);
            fadeTransition6.setFromValue(0);
            fadeTransition6.setToValue(1);
            fadeTransition6.setDuration(Duration.seconds(3));
            fadeTransition6.play();

            FadeTransition fadeTransition2 = new FadeTransition(Duration.millis(3000), circle2);
            fadeTransition2.setFromValue(0);
            fadeTransition2.setToValue(1);
            fadeTransition2.setDuration(Duration.seconds(3));
            fadeTransition2.play();

            FadeTransition fadeTransition1 = new FadeTransition(Duration.millis(3000), circle1);
            fadeTransition1.setFromValue(0);
            fadeTransition1.setToValue(1);
            fadeTransition1.setDuration(Duration.seconds(4));
            fadeTransition1.play();

            FadeTransition fadeTransition7 = new FadeTransition(Duration.millis(3000), circle7);
            fadeTransition7.setFromValue(0);
            fadeTransition7.setToValue(1);
            fadeTransition7.setDuration(Duration.seconds(4));
            fadeTransition7.play();

            //fade out
            FadeOutUp fadeup4 = new FadeOutUp(circle4);
            fadeup4.setCycleCount(1).setDelay(Duration.seconds(1)).play();

            FadeOutUp fadeup3 = new FadeOutUp(circle3);
            fadeup3.setCycleCount(1).setDelay(Duration.seconds(1.2)).play();

            FadeOutUp fadeup5 = new FadeOutUp(circle5);
            fadeup5.setCycleCount(1).setDelay(Duration.seconds(1.2)).play();

            FadeOutUp fadeup2 = new FadeOutUp(circle2);
            fadeup2.setCycleCount(1).setDelay(Duration.seconds(1.4)).play();

            FadeOutUp fadeup6 = new FadeOutUp(circle6);
            fadeup6.setCycleCount(1).setDelay(Duration.seconds(1.4)).play();

            FadeOutUp fadeup1 = new FadeOutUp(circle1);
            fadeup1.setCycleCount(1).setDelay(Duration.seconds(1.6)).play();

            FadeOutUp fadeup7 = new FadeOutUp(circle7);
            fadeup7.setCycleCount(1).setDelay(Duration.seconds(1.6)).play();

            ///Fade In

            FadeOutDown fadedown4 = new FadeOutDown(circle4);
            fadedown4.setCycleCount(1).setDelay(Duration.seconds(2)).play();

            FadeOutDown fadedown5 = new FadeOutDown(circle5);
            fadedown5.setCycleCount(1).setDelay(Duration.seconds(2.2)).play();

            FadeOutDown fadedown3 = new FadeOutDown(circle3);
            fadedown3.setCycleCount(1).setDelay(Duration.seconds(2.2)).play();

            FadeOutDown fadedown6 = new FadeOutDown(circle6);
            fadedown6.setCycleCount(1).setDelay(Duration.seconds(2.4)).play();

            FadeOutDown fadedown2 = new FadeOutDown(circle2);
            fadedown2.setCycleCount(1).setDelay(Duration.seconds(2.4)).play();

            FadeOutDown fadedown7 = new FadeOutDown(circle7);
            fadedown7.setCycleCount(1).setDelay(Duration.seconds(2.6)).play();

            FadeOutDown fadedown1 = new FadeOutDown(circle1);
            fadedown1.setCycleCount(1).setDelay(Duration.seconds(2.6)).play();

            //Fade out
            FadeInDown fadeInDown4 = new FadeInDown(circle4);
            fadeInDown4.setCycleCount(1).setDelay(Duration.seconds(2)).play();

            FadeInDown fadeInDown5 = new FadeInDown(circle5);
            fadeInDown5.setCycleCount(1).setDelay(Duration.seconds(2.2)).play();

            FadeInDown fadeInDown3 = new FadeInDown(circle3);
            fadeInDown3.setCycleCount(1).setDelay(Duration.seconds(2.2)).play();

            FadeInDown fadeInDown6 = new FadeInDown(circle6);
            fadeInDown6.setCycleCount(1).setDelay(Duration.seconds(2.4)).play();

            FadeInDown fadeInDown2 = new FadeInDown(circle2);
            fadeInDown2.setCycleCount(1).setDelay(Duration.seconds(2.4)).play();

            FadeInDown fadeInDown7 = new FadeInDown(circle7);
            fadeInDown7.setCycleCount(1).setDelay(Duration.seconds(2.6)).play();

            FadeInDown fadeInDown1 = new FadeInDown(circle1);
            fadeInDown1.setCycleCount(1).setDelay(Duration.seconds(2.6)).play();

            //Fade down

            FadeOutDown fadeOutDown4 = new FadeOutDown(circle4);
            fadeOutDown4.setCycleCount(1).setDelay(Duration.seconds(3)).play();

            FadeOutDown fadeOutDown3 = new FadeOutDown(circle3);
            fadeOutDown3.setCycleCount(1).setDelay(Duration.seconds(3.2)).play();

            FadeOutDown fadeOutDown5 = new FadeOutDown(circle5);
            fadeOutDown5.setCycleCount(1).setDelay(Duration.seconds(3.2)).play();

            FadeOutDown fadeOutDown6 = new FadeOutDown(circle6);
            fadeOutDown6.setCycleCount(1).setDelay(Duration.seconds(3.4)).play();

            FadeOutDown fadeOutDown2 = new FadeOutDown(circle2);
            fadeOutDown2.setCycleCount(1).setDelay(Duration.seconds(3.4)).play();

            FadeOutDown fadeOutDown1 = new FadeOutDown(circle1);
            fadeOutDown1.setCycleCount(1).setDelay(Duration.seconds(3.6)).play();

            FadeOutDown fadeOutDown7 = new FadeOutDown(circle7);
            fadeOutDown7.setCycleCount(1).setDelay(Duration.seconds(3.6)).play();

            //Fadein up

            FadeInUp fadeInUp4 = new FadeInUp(circle4);
            fadeInUp4.setCycleCount(1).setDelay(Duration.seconds(4)).play();

            FadeInUp fadeInUp3 = new FadeInUp(circle3);
            fadeInUp3.setCycleCount(1).setDelay(Duration.seconds(5)).play();

            FadeInUp fadeInUp5 = new FadeInUp(circle5);
            fadeInUp5.setCycleCount(1).setDelay(Duration.seconds(5.5)).play();

            FadeInUp fadeInUp2 = new FadeInUp(circle2);
            fadeInUp2.setCycleCount(1).setDelay(Duration.seconds(5.9)).play();

            FadeInUp fadeInUp6 = new FadeInUp(circle6);
            fadeInUp6.setCycleCount(1).setDelay(Duration.seconds(6.1)).play();

            FadeInUp fadeInUp1 = new FadeInUp(circle1);
            fadeInUp1.setCycleCount(1).setDelay(Duration.seconds(6.3)).play();

            FadeInUp fadeInUp7 = new FadeInUp(circle7);
            fadeInUp7.setCycleCount(1).setDelay(Duration.seconds(6.5)).play();



    }
}
